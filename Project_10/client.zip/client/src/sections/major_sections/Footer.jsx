/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React from 'react';

const Footer = () => {

  return (
    <div>
        <div className='bg-gradient-to-r from-blue-400 to-purple-400 justify-center items-center text-slate-200 rounded-md'>
            <h1 className='text-center text-bolds'>Copyright@FinanSage.Official</h1>
        </div>
    </div>
  );
}

export default Footer;